SPL Compiler
============

**Introduction** : SPL (System Programmer’s Language) Compiler is used in the implementation of an operating system on XSM (eXperimental String Machine). The compiler compiles the code written in SPL and translates it into machine code which is simulated on the machine.

Prerequisites :
-------------
	• GCC (GNU project C and C++ compiler)
	• Flex / Lex (Fast Lexical Analyser Generator)
	• Bison / Yacc (GNU Project Parser Generator)

Compiling and Running :
---------------------
Run the following commands to compile and run the SPL compiler:
1. `make`
2. `./spl <path-to-file>`